from __future__ import annotations

import sys
import os
import subprocess
import shutil
from pathlib import Path
from datetime import datetime

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QFileDialog, QTextEdit,
    QCheckBox, QComboBox, QGroupBox, QMessageBox, QSplashScreen,
    QProgressBar
)

# =============================================================================
# Global Definitions
# =============================================================================
APP_NAME = "Packages of Death"
ORG_NAME = "Death's Head Software"
VERSION = "1.0.0"

# =============================================================================
# Splash Screen
# =============================================================================
def create_splash():
    """Creates the QSplashScreen with skull ASCII art."""
    try:
        # Check for external splash.png in the same directory as the script
        splash_path = Path(__file__).parent / "splash.png"
        
        if splash_path.exists():
            # Load the splash.png file
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                # If loading failed, create fallback
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            else:
                # Scale if needed
                if pixmap.width() != 800 or pixmap.height() != 600:
                    pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                           Qt.TransformationMode.SmoothTransformation)
            
            # Add text overlay to the image
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 100)
            footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback: Generate the dark-themed screen with ASCII art skull
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 50)
            footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# Package Builder Thread
# =============================================================================
class PackageBuilderThread(QThread):
    """Thread for building packages without blocking the UI."""
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, app_path, output_path, install_location, package_id, version, sign_identity=None):
        super().__init__()
        self.app_path = app_path
        self.output_path = output_path
        self.install_location = install_location
        self.package_id = package_id
        self.version = version
        self.sign_identity = sign_identity
    
    def run(self):
        try:
            self.progress.emit("Starting package build...")
            
            # Create temporary directory for package structure
            temp_dir = Path("/tmp") / f"pkg_build_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            temp_dir.mkdir(exist_ok=True)
            
            self.progress.emit(f"Created temporary directory: {temp_dir}")
            
            # Create root directory structure
            # The root should contain the full path structure starting from /
            root_dir = temp_dir / "root"
            
            # Remove leading slash and create the full path
            install_path = self.install_location.lstrip('/')
            payload_dir = root_dir / install_path
            payload_dir.mkdir(parents=True, exist_ok=True)
            
            self.progress.emit(f"Copying application to {self.install_location}...")
            
            # Copy the app to payload
            app_name = Path(self.app_path).name
            dest_app = payload_dir / app_name
            
            # Use ditto for better macOS app copying (preserves metadata, resources, etc.)
            self.progress.emit(f"Using ditto to copy {app_name}...")
            ditto_result = subprocess.run(
                ["ditto", self.app_path, str(dest_app)],
                capture_output=True,
                text=True
            )
            
            if ditto_result.returncode != 0:
                self.finished.emit(False, f"Failed to copy app: {ditto_result.stderr}")
                return
            
            # Create scripts directory for post-install verification
            scripts_dir = temp_dir / "scripts"
            scripts_dir.mkdir(exist_ok=True)
            
            # Create postinstall script
            postinstall_script = scripts_dir / "postinstall"
            postinstall_content = f"""#!/bin/bash
# Post-installation script
echo "Package installed successfully"
echo "Installation location: {self.install_location}/{app_name}"
ls -la "{self.install_location}/{app_name}" || echo "WARNING: App not found at expected location"
exit 0
"""
            postinstall_script.write_text(postinstall_content)
            postinstall_script.chmod(0o755)
            
            self.progress.emit("Building package with pkgbuild...")
            
            # Build the package
            pkg_cmd = [
                "pkgbuild",
                "--root", str(root_dir),
                "--identifier", self.package_id,
                "--version", self.version,
                "--install-location", "/",
                "--scripts", str(scripts_dir)
            ]
            
            if self.sign_identity:
                pkg_cmd.extend(["--sign", self.sign_identity])
                self.progress.emit(f"Signing with identity: {self.sign_identity}")
            
            pkg_cmd.append(self.output_path)
            
            self.progress.emit(f"Running: {' '.join(pkg_cmd)}")
            
            result = subprocess.run(pkg_cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                self.finished.emit(False, f"pkgbuild failed: {result.stderr}\n{result.stdout}")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            
            self.progress.emit("Package built successfully!")
            self.progress.emit(f"stdout: {result.stdout}")
            
            # Verify the package was created
            if not Path(self.output_path).exists():
                self.finished.emit(False, "Package file was not created")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return
            
            pkg_size = Path(self.output_path).stat().st_size
            self.progress.emit(f"Package size: {pkg_size / 1024 / 1024:.2f} MB")
            
            # Inspect the package contents
            self.progress.emit("Inspecting package contents...")
            inspect_result = subprocess.run(
                ["pkgutil", "--payload-files", self.output_path],
                capture_output=True,
                text=True
            )
            
            if inspect_result.returncode == 0:
                self.progress.emit("Package contents:")
                for line in inspect_result.stdout.strip().split('\n')[:20]:  # Show first 20 files
                    self.progress.emit(f"  {line}")
            
            # Get package info
            info_result = subprocess.run(
                ["pkgutil", "--pkg-info-plist", self.output_path],
                capture_output=True,
                text=True
            )
            
            if info_result.returncode == 0:
                self.progress.emit("Package info retrieved")
            
            # Clean up
            shutil.rmtree(temp_dir)
            self.progress.emit("Cleaned up temporary files")
            
            success_msg = f"""Package created successfully!
{self.output_path}
Installs to: {self.install_location}/{app_name}

INSTALLATION INSTRUCTIONS:
1. Double-click the .pkg file
2. Follow the installer prompts
3. Check /var/log/install.log for installation details
4. After installing, check: {self.install_location}/{app_name}

To view installation log, run in Terminal:
  tail -f /var/log/install.log
"""
            
            self.finished.emit(True, success_msg)
            
        except Exception as e:
            self.finished.emit(False, f"Error: {str(e)}")

# =============================================================================
# Main Window
# =============================================================================
class MainWindow(QMainWindow):
    """Main application window for Packages of Death."""
    
    def __init__(self):
        super().__init__()
        self.builder_thread = None
        self.init_ui()
        self.apply_dark_theme()
    
    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle(f"{APP_NAME} v{VERSION}")
        self.setGeometry(100, 100, 900, 700)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Title
        title = QLabel(APP_NAME)
        title.setFont(QFont("Courier", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Application Selection Group
        app_group = QGroupBox("Application Selection")
        app_layout = QVBoxLayout()
        
        app_select_layout = QHBoxLayout()
        self.app_path_edit = QLineEdit()
        self.app_path_edit.setPlaceholderText("Select .app bundle to package...")
        app_select_layout.addWidget(self.app_path_edit)
        
        browse_app_btn = QPushButton("Browse...")
        browse_app_btn.clicked.connect(self.browse_app)
        app_select_layout.addWidget(browse_app_btn)
        
        app_layout.addLayout(app_select_layout)
        app_group.setLayout(app_layout)
        layout.addWidget(app_group)
        
        # Package Configuration Group
        config_group = QGroupBox("Package Configuration")
        config_layout = QVBoxLayout()
        
        # Install location
        install_layout = QHBoxLayout()
        install_layout.addWidget(QLabel("Install Location:"))
        self.install_combo = QComboBox()
        self.install_combo.addItems(["/Applications", "/usr/local", "/Library", "Custom..."])
        self.install_combo.currentTextChanged.connect(self.on_install_location_changed)
        install_layout.addWidget(self.install_combo)
        
        self.custom_install_edit = QLineEdit()
        self.custom_install_edit.setPlaceholderText("Enter custom path...")
        self.custom_install_edit.setVisible(False)
        install_layout.addWidget(self.custom_install_edit)
        
        config_layout.addLayout(install_layout)
        
        # Package ID
        id_layout = QHBoxLayout()
        id_layout.addWidget(QLabel("Package Identifier:"))
        self.package_id_edit = QLineEdit()
        self.package_id_edit.setPlaceholderText("com.yourcompany.appname")
        self.package_id_edit.setText("com.deathshead.package")
        id_layout.addWidget(self.package_id_edit)
        config_layout.addLayout(id_layout)
        
        # Version
        version_layout = QHBoxLayout()
        version_layout.addWidget(QLabel("Version:"))
        self.version_edit = QLineEdit()
        self.version_edit.setPlaceholderText("1.0.0")
        self.version_edit.setText("1.0.0")
        version_layout.addWidget(self.version_edit)
        config_layout.addLayout(version_layout)
        
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # Signing Group
        signing_group = QGroupBox("Code Signing")
        signing_layout = QVBoxLayout()
        
        self.sign_checkbox = QCheckBox("Sign package")
        self.sign_checkbox.toggled.connect(self.on_sign_toggled)
        signing_layout.addWidget(self.sign_checkbox)
        
        sign_id_layout = QHBoxLayout()
        sign_id_layout.addWidget(QLabel("Signing Identity:"))
        self.sign_identity_edit = QLineEdit()
        self.sign_identity_edit.setPlaceholderText("Developer ID Installer: Your Name (XXXXXXXXXX)")
        self.sign_identity_edit.setEnabled(False)
        sign_id_layout.addWidget(self.sign_identity_edit)
        
        list_identities_btn = QPushButton("List Identities")
        list_identities_btn.clicked.connect(self.list_signing_identities)
        sign_id_layout.addWidget(list_identities_btn)
        
        signing_layout.addLayout(sign_id_layout)
        signing_group.setLayout(signing_layout)
        layout.addWidget(signing_group)
        
        # Output Group
        output_group = QGroupBox("Output")
        output_layout = QVBoxLayout()
        
        output_select_layout = QHBoxLayout()
        self.output_path_edit = QLineEdit()
        self.output_path_edit.setPlaceholderText("Select output .pkg file location...")
        output_select_layout.addWidget(self.output_path_edit)
        
        browse_output_btn = QPushButton("Browse...")
        browse_output_btn.clicked.connect(self.browse_output)
        output_select_layout.addWidget(browse_output_btn)
        
        output_layout.addLayout(output_select_layout)
        output_group.setLayout(output_layout)
        layout.addWidget(output_group)
        
        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Log
        log_label = QLabel("Build Log:")
        layout.addWidget(log_label)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(150)
        layout.addWidget(self.log_text)
        
        # Build button
        self.build_btn = QPushButton("Build Package")
        self.build_btn.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        self.build_btn.setMinimumHeight(50)
        self.build_btn.clicked.connect(self.build_package)
        layout.addWidget(self.build_btn)
        
        # Inspect button
        self.inspect_btn = QPushButton("Inspect Package")
        self.inspect_btn.clicked.connect(self.inspect_package)
        layout.addWidget(self.inspect_btn)
        
        # View install log button
        self.log_btn = QPushButton("View Installation Log")
        self.log_btn.clicked.connect(self.view_install_log)
        layout.addWidget(self.log_btn)
        
        # Check installed packages button
        self.check_btn = QPushButton("Check Installed Packages")
        self.check_btn.clicked.connect(self.check_installed_packages)
        layout.addWidget(self.check_btn)
    
    def apply_dark_theme(self):
        """Apply dark theme to the application."""
        dark_stylesheet = """
            QMainWindow, QWidget {
                background-color: #1e1e1e;
                color: #e0e0e0;
            }
            QGroupBox {
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                color: #e0e0e0;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QLineEdit, QTextEdit, QComboBox {
                background-color: #2d2d2d;
                border: 1px solid #3d3d3d;
                border-radius: 3px;
                padding: 5px;
                color: #e0e0e0;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 1px solid #5a5a5a;
            }
            QPushButton {
                background-color: #3d3d3d;
                border: 1px solid #5a5a5a;
                border-radius: 3px;
                padding: 8px;
                color: #e0e0e0;
            }
            QPushButton:hover {
                background-color: #4d4d4d;
            }
            QPushButton:pressed {
                background-color: #2d2d2d;
            }
            QCheckBox {
                color: #e0e0e0;
            }
            QLabel {
                color: #e0e0e0;
            }
            QProgressBar {
                border: 1px solid #3d3d3d;
                border-radius: 3px;
                text-align: center;
                background-color: #2d2d2d;
            }
            QProgressBar::chunk {
                background-color: #5a5a5a;
            }
        """
        self.setStyleSheet(dark_stylesheet)
    
    def on_install_location_changed(self, text):
        """Handle install location change."""
        if text == "Custom...":
            self.custom_install_edit.setVisible(True)
        else:
            self.custom_install_edit.setVisible(False)
    
    def on_sign_toggled(self, checked):
        """Handle signing checkbox toggle."""
        self.sign_identity_edit.setEnabled(checked)
    
    def browse_app(self):
        """Browse for application bundle."""
        path = QFileDialog.getOpenFileName(
            self,
            "Select Application Bundle",
            os.path.expanduser("~/Applications"),
            "Applications (*.app)"
        )[0]
        if path:
            self.app_path_edit.setText(path)
    
    def browse_output(self):
        """Browse for output package location."""
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Package As",
            os.path.expanduser("~/Desktop/package.pkg"),
            "Package Files (*.pkg)"
        )
        if path:
            if not path.endswith('.pkg'):
                path += '.pkg'
            self.output_path_edit.setText(path)
    
    def list_signing_identities(self):
        """List available signing identities."""
        try:
            result = subprocess.run(
                ["security", "find-identity", "-v", "-p", "basic"],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                msg = QMessageBox()
                msg.setWindowTitle("Available Signing Identities")
                msg.setText("Available identities:")
                msg.setDetailedText(result.stdout)
                msg.exec()
            else:
                QMessageBox.warning(self, "Error", "Failed to list identities")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to list identities: {str(e)}")
    
    def log(self, message):
        """Add message to log."""
        self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
    
    def build_package(self):
        """Build the package."""
        # Validate inputs
        if not self.app_path_edit.text():
            QMessageBox.warning(self, "Error", "Please select an application bundle")
            return
        
        if not self.output_path_edit.text():
            QMessageBox.warning(self, "Error", "Please specify output location")
            return
        
        if not self.package_id_edit.text():
            QMessageBox.warning(self, "Error", "Please specify package identifier")
            return
        
        if not self.version_edit.text():
            QMessageBox.warning(self, "Error", "Please specify version")
            return
        
        # Check if app already exists at install location
        app_name = Path(self.app_path_edit.text()).name
        install_location = self.install_combo.currentText()
        if install_location == "Custom...":
            install_location = self.custom_install_edit.text()
            if not install_location:
                QMessageBox.warning(self, "Error", "Please specify custom install location")
                return
        
        target_path = Path(install_location) / app_name
        if target_path.exists():
            reply = QMessageBox.question(
                self,
                "App Already Exists",
                f"An app already exists at {target_path}\n\n"
                "macOS Installer may 'relocate' the app back to the source location instead of installing it.\n\n"
                "Would you like to remove the existing app first?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel
            )
            
            if reply == QMessageBox.StandardButton.Cancel:
                return
            elif reply == QMessageBox.StandardButton.Yes:
                try:
                    # Remove with sudo
                    result = subprocess.run(
                        ["osascript", "-e", 
                         f'do shell script "rm -rf \\"{target_path}\\"" with administrator privileges'],
                        capture_output=True,
                        text=True
                    )
                    if result.returncode == 0:
                        self.log(f"Removed existing app at {target_path}")
                    else:
                        QMessageBox.warning(self, "Error", f"Failed to remove existing app: {result.stderr}")
                        return
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to remove existing app: {str(e)}")
                    return
        
        # Clear log
        self.log_text.clear()
        
        # Show progress bar
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # Indeterminate
        
        # Disable build button
        self.build_btn.setEnabled(False)
        
        # Create and start builder thread
        self.builder_thread = PackageBuilderThread(
            self.app_path_edit.text(),
            self.output_path_edit.text(),
            install_location,
            self.package_id_edit.text(),
            self.version_edit.text(),
            self.sign_identity_edit.text() if self.sign_checkbox.isChecked() else None
        )
        self.builder_thread.progress.connect(self.log)
        self.builder_thread.finished.connect(self.on_build_finished)
        self.builder_thread.start()
    
    def on_build_finished(self, success, message):
        """Handle build completion."""
        self.progress_bar.setVisible(False)
        self.build_btn.setEnabled(True)
        
        self.log(message)
        
        if success:
            QMessageBox.information(self, "Success", message)
        else:
            QMessageBox.critical(self, "Error", message)
    
    def inspect_package(self):
        """Inspect an existing package file."""
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Package to Inspect",
            os.path.expanduser("~/Desktop"),
            "Package Files (*.pkg)"
        )
        
        if not path:
            return
        
        self.log_text.clear()
        self.log(f"Inspecting package: {path}")
        
        # Get package contents
        self.log("\n=== Package Contents ===")
        result = subprocess.run(
            ["pkgutil", "--payload-files", path],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            files = result.stdout.strip().split('\n')
            self.log(f"Total files: {len(files)}")
            for line in files[:50]:  # Show first 50 files
                self.log(f"  {line}")
            if len(files) > 50:
                self.log(f"  ... and {len(files) - 50} more files")
        else:
            self.log(f"Error reading contents: {result.stderr}")
        
        # Get package info
        self.log("\n=== Package Info ===")
        result = subprocess.run(
            ["pkgutil", "--pkg-info", path],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            self.log(result.stdout)
        else:
            self.log(f"Error reading info: {result.stderr}")
        
        # Get BOM (Bill of Materials)
        self.log("\n=== Expanded Package Structure ===")
        result = subprocess.run(
            ["pkgutil", "--bom", path],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            self.log(f"BOM file: {result.stdout.strip()}")
            # Try to read the BOM
            bom_result = subprocess.run(
                ["lsbom", result.stdout.strip()],
                capture_output=True,
                text=True
            )
            if bom_result.returncode == 0:
                lines = bom_result.stdout.strip().split('\n')
                for line in lines[:30]:
                    self.log(f"  {line}")
                if len(lines) > 30:
                    self.log(f"  ... and {len(lines) - 30} more entries")
    
    def view_install_log(self):
        """View the macOS installation log."""
        self.log_text.clear()
        self.log("=== macOS Installation Log (last 100 lines) ===\n")
        
        # Read the install log
        try:
            result = subprocess.run(
                ["tail", "-100", "/var/log/install.log"],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                self.log(result.stdout)
            else:
                self.log("Could not read /var/log/install.log")
                self.log("You may need to run: sudo tail -f /var/log/install.log")
        except Exception as e:
            self.log(f"Error reading install log: {e}")
            self.log("\nTo view the install log in Terminal, run:")
            self.log("  tail -f /var/log/install.log")
            self.log("\nOr to see recent installations:")
            self.log("  grep -i 'install' /var/log/install.log | tail -50")
    
    def check_installed_packages(self):
        """Check what packages are installed and where their files are."""
        self.log_text.clear()
        
        # Get package ID from the input field
        pkg_id = self.package_id_edit.text()
        
        if not pkg_id:
            self.log("Please enter a package identifier to search for.")
            return
        
        self.log(f"Checking for package: {pkg_id}\n")
        
        # Check if package is installed
        self.log("=== Checking Package Receipt ===")
        result = subprocess.run(
            ["pkgutil", "--pkg-info", pkg_id],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            self.log("✓ Package IS installed!")
            self.log(result.stdout)
        else:
            self.log("✗ Package NOT found in receipts")
            self.log(f"Error: {result.stderr}")
            self.log("\nSearching for similar packages...")
            
            # List all packages
            list_result = subprocess.run(
                ["pkgutil", "--pkgs"],
                capture_output=True,
                text=True
            )
            
            if list_result.returncode == 0:
                matching = [p for p in list_result.stdout.split('\n') 
                           if 'death' in p.lower() or 'encryption' in p.lower()]
                if matching:
                    self.log("Found similar packages:")
                    for p in matching:
                        self.log(f"  - {p}")
        
        # Check where files were installed
        self.log("\n=== Checking Installed Files ===")
        files_result = subprocess.run(
            ["pkgutil", "--files", pkg_id],
            capture_output=True,
            text=True
        )
        
        if files_result.returncode == 0:
            files = files_result.stdout.strip().split('\n')
            self.log(f"Package installed {len(files)} files:")
            for f in files[:50]:
                self.log(f"  {f}")
            if len(files) > 50:
                self.log(f"  ... and {len(files) - 50} more files")
        else:
            self.log("Could not list installed files")
        
        # Check volume where package was installed
        self.log("\n=== Package Volume ===")
        vol_result = subprocess.run(
            ["pkgutil", "--pkg-info-plist", pkg_id],
            capture_output=True,
            text=True
        )
        
        if vol_result.returncode == 0:
            self.log("Package info (plist):")
            # Parse for volume and install-location
            for line in vol_result.stdout.split('\n'):
                if 'volume' in line.lower() or 'install-location' in line.lower() or 'location' in line.lower():
                    self.log(f"  {line}")
        
        # Check /Applications directly
        self.log("\n=== Checking /Applications ===")
        app_name = Path(self.app_path_edit.text()).name if self.app_path_edit.text() else "*.app"
        
        try:
            result = subprocess.run(
                ["ls", "-la", "/Applications"],
                capture_output=True,
                text=True
            )
            
            if "Encryption" in result.stdout or "Death" in result.stdout:
                self.log("Found matching apps in /Applications:")
                for line in result.stdout.split('\n'):
                    if 'Encryption' in line or 'Death' in line:
                        self.log(f"  {line}")
            else:
                self.log("No matching apps found in /Applications")
                self.log("\nAll .app bundles in /Applications:")
                for line in result.stdout.split('\n'):
                    if '.app' in line:
                        self.log(f"  {line}")
        except Exception as e:
            self.log(f"Error checking /Applications: {e}")

# =============================================================================
# Main Application
# =============================================================================
def main():
    """Main application entry point."""
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    
    # Create and show splash screen
    splash = create_splash()
    if splash:
        splash.show()
        app.processEvents()
        
        # Simulate loading with 5.4 second duration
        messages = [
            ("Initializing Death's Head...", 1.0),
            ("Loading Package Tools...", 1.5),
            ("Preparing Build Environment...", 1.4),
            ("Almost Ready...", 1.5)
        ]
        
        for msg, duration in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            app.processEvents()
            QThread.msleep(int(duration * 1000))
    
    # Create and show main window
    main_window = MainWindow()
    
    if splash:
        splash.finish(main_window)
    
    main_window.show()
    
    sys.exit(app.exec())

if __name__ == '__main__':
    main()