*Note: When you install any package you build,
you want to make sure there are no copies of the 
app on your Mac. If there is a copy, Mac OS will "upgrade"
in place that copy of the app. The trick is to remove 
all copies of the app from your Mac before you install
the package.